; void in_MouseAMXInit(uchar xvector, uchar yvector)
; CALLER linkage for function pointers

XLIB in_MouseAMXInit

LIB in_MouseAMXInit_callee
XREF ASMDISP_IN_MOUSEAMXINIT_CALLEE

.in_MouseAMXInit

   pop hl
   pop bc
   pop de
   push de
   push bc
   push hl
   
   ld b,e
   jp in_MouseAMXInit_callee + ASMDISP_IN_MOUSEAMXINIT_CALLEE
