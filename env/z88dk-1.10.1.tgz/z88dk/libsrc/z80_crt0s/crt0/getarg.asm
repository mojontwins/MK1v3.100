;       Z88 Small C+ Run time Library
;       Moved functions over to proper libdefs
;       To make startup code smaller and neater!
;
;       This routine is needed by printf & scanf etc
;       Added   10/10/98 djm

                XLIB    getarg
                LIB     l_sxt

.getarg
        jp      l_sxt


