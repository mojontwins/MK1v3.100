;       Z88 Small C+ Run time Library
;       Moved functions over to proper libdefs
;       To make startup code smaller and neater!
;
;       6/9/98  djm

                XLIB    l_bool


.l_bool
        ld a,h
        or l
        ret z
        ld hl,1
        ret
